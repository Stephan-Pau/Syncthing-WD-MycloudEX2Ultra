#!/bin/sh

# stop daemon
APKG_DIR=-shares/Volume_1/Nas_Prog/syncthing/syncthing
#. ${APKG_DIR}/env

pkill ${BINARY}

p=$(pidof ${BINARY} > /dev/null)
while [ -n "$p" ] ; do
	echo "Stopping ${APKG_NAME}"
	kill $p
	sleep 1
	p=$(pidof ${BINARY} > /dev/null)
done

